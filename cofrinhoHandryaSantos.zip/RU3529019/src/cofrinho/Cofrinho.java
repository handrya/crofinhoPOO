package cofrinho;

import java.util.ArrayList;

public class Cofrinho {
	
	private ArrayList<Moeda> listagemMoedas;
		
	public Cofrinho () {
		this.listagemMoedas = new ArrayList<>();
	}

	public void adicionar (Moeda moeda) {
		this.listagemMoedas.add(moeda);
	}
	
	public boolean remover (Moeda moeda) {
		return this.listagemMoedas.remove(moeda);
	}

	public void listarMoedas () {
		
		if (this.listagemMoedas.isEmpty()) { //verifica se há itens na lista
			System.out.println("Cofrinho está vazio!");
		}
		
		for (Moeda moeda : this.listagemMoedas) {
			moeda.info();
		}
		System.out.println();
	}
	
	public double converterMoeda () {
		if (this.listagemMoedas.isEmpty()) {
			return 0;
		}
		
		//os cálculos de conversão são recuperados da função de cada classe filha de Moeda
		double valorSomado = 0;
		
		for (Moeda moeda : this.listagemMoedas) {
			valorSomado = valorSomado + moeda.converter();		
		}
		
		return valorSomado;
	}

}
