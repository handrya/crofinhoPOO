package cofrinho;

public class Dolar extends Moeda{
	public Dolar (double valorDolar) {
		this.valor = valorDolar;
	}
		
	@Override
	public void info() {
		System.out.println("Dólar - US$" + valor);
		
	}

	@Override
	// calculo do dólar em Real de acordo com a cotação atual
	public double converter() {
		return this.valor*4.99;
	}

	@Override
	//especificação dos valores para função removerMoeda funcionar
	public boolean equals (Object obj) {
		if (this.getClass() != obj.getClass()) {
			return false;
		}
		
		Dolar objDolar = (Dolar) obj;
		
		if (this.valor != objDolar.valor) {
			return false;
		}
		
		return true;
	}

}
