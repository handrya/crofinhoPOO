package cofrinho;

import java.util.Scanner;

public class Menu {
	
	private Scanner entrada;
	private Cofrinho cofre;
	
	public Menu() {
		entrada = new Scanner(System.in);
		cofre = new Cofrinho();
	}
	
	
	public void executarMenuPrincipal () { 
		System.out.println("Cofrinho - RU3529019");
		System.out.println("1 - Adicionar");
		System.out.println("2 - Remover");
		System.out.println("3 - Listar");
		System.out.println("4 - Total em Reais (R$)");
		System.out.println("0 - Encerrar");
		
		String opcao = entrada.next();
		
		System.out.println(opcao);
		
		switch (opcao) {
			case "0":
				System.out.println("Sistema encerrado!");
				break;
				
			case "1":
				adicionarMoeda(); //descrito abaixo para deixar este menu mais limpo
				System.out.println();
				executarMenuPrincipal();
				break;
				
			case "2":
				removerMoeda(); //descrito abaixo para deixar este menu mais limpo
				System.out.println();
				executarMenuPrincipal();
				break;
			
			case "3": //toda a função é recuperada da classe Cofrinho
				cofre.listarMoedas();
				System.out.println();
				executarMenuPrincipal();
				break;
			
			case "4": //função recuperada da classe cofrinho 
				double somaConvertida = cofre.converterMoeda();
				System.out.println("Valor total convertido para Real (R$): " + somaConvertida);
				executarMenuPrincipal();
				break;
				
			default:
				System.out.println("Opção Inválida, favor escolher entre 0 e 4!");
				executarMenuPrincipal();			
				break;
		}
	}
	
	//método para o menu de adição de moedas
		private void adicionarMoeda() {
			System.out.println("Selecione uma opção de Moeda");
			System.out.println("1 - Dolar");
			System.out.println("2 - Euro");
			System.out.println("3 - Real");
			System.out.println("0 - Retornar ao menu inicial");
			
			int opcaoMoeda = entrada.nextInt();
			
			if (opcaoMoeda == 0) {
				executarMenuPrincipal();
			}
			
			System.out.println("Qual o valor você deseja depositar?");
			String deposito = entrada.next();
			double valorDeposito = Double.valueOf(deposito);
			
			Moeda moeda = null;
			
			if (opcaoMoeda == 1) {
				moeda = new Dolar(valorDeposito);
			}
				
			else if (opcaoMoeda == 2) {
				moeda = new Euro (valorDeposito);
			}
			
			else if	(opcaoMoeda == 3) {
				moeda = new Real (valorDeposito);
			}
				
			else {
				System.out.println("Opção Inválida!");				
			}
			
			cofre.adicionar(moeda);
			System.out.println("Valor depositado!");
		}
		
	
	//método para o menu de remoção de moedas
		private void removerMoeda() {
			System.out.println("Selecione uma opção de Moeda");
			System.out.println("1 - Dolar");
			System.out.println("2 - Euro");
			System.out.println("3 - Real");
			System.out.println("0 - Retornar ao menu inicial");
			
			int opcaoMoeda = entrada.nextInt();
			
			if (opcaoMoeda == 0) {
				executarMenuPrincipal();
				
			}
			
			System.out.println("Qual o moeda você deseja remover?");
			String saque = entrada.next();
			double valorSaque = Double.valueOf(saque);
			
			Moeda moeda=null;		
			
			if (opcaoMoeda == 1) {
				moeda = new Dolar(valorSaque);
			}
			
			else if (opcaoMoeda == 2) {
				moeda = new Euro (valorSaque);
			}
			
			else if (opcaoMoeda == 3) {
				moeda = new Real (valorSaque);
			}
			
			else {
				System.out.println("Opção Inválida!");
				removerMoeda();
			}
			
			if (cofre.remover(moeda)) {
				System.out.println("Moeda removida!");
				
			}
			
			else {
				System.out.println("Moeda não encontrada no Cofrinho");
			}
			
		}

}