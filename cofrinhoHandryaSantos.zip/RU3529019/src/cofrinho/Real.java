package cofrinho;

public class Real extends Moeda {
	public Real (double valorReal) {
		this.valor = valorReal;
	}
		

	@Override
	public void info() {
		System.out.println("Real - R$" + valor);
		
	}

	@Override
	//como já está em real, não é preciso um cálculo
	public double converter() {
		return this.valor;
		
	}
	
	@Override 
	//especificação dos valores para função removerMoeda funcionar
	public boolean equals (Object obj) {
		if (this.getClass() != obj.getClass()) {
			return false;
		}
		
		Real objReal = (Real) obj;
		
		if (this.valor != objReal.valor) {
			return false;
		}
		
		return true;
	}

}
