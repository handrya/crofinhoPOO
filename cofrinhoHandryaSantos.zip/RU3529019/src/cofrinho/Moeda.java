package cofrinho;

public abstract class Moeda {
	double valor;
	
	public abstract void info();
	public abstract double converter();

}
