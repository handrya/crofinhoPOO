package cofrinho;

public class Euro extends Moeda{
	public Euro (double valorEuro) {
		this.valor = valorEuro;
	}
		
	@Override
	public void info() {
		System.out.println("Euro - €" + valor);
		
	}

	@Override
	// calculo do euro em Real de acordo com a cotação atual
	public double converter() {
		return this.valor*5.36;
	}
	@Override
	//especificação dos valores para função removerMoeda funcionar
	public boolean equals (Object obj) {
		if (this.getClass() != obj.getClass()) {
			return false;
		}
		
		Euro objEuro = (Euro) obj;
		
		if (this.valor != objEuro.valor) {
			return false;
		}
		
		return true;
	}

}