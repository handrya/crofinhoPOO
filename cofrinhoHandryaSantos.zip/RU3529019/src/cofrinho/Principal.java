package cofrinho;

public class Principal {

	public static void main(String[] args) {
		System.out.println("Cofrinho da Hândrya Santos - RU3529019");
		System.out.println();
		
		
		//para manter a classe principal mais limpa e faciltar a manutenção do código, a classe Menu foi criada.
		Menu menu = new Menu();
		menu.executarMenuPrincipal();
		
		}

}